import SuccessWithdraw from './SuccessWithdraw/SuccessWithdraw'
import Message from './Message/Message'
import ErrorNotification from './ErrorNotification/ErrorNotification'


export default {
  SuccessWithdraw,
  Message,
  ErrorNotification,
}

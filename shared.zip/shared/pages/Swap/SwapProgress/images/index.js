
import icon0 from './icon0.gif'
import icon1 from './icon1.gif'
import icon2 from './icon2.gif'
import icon3 from './icon3.gif'
import icon4 from './icon4.gif'
import icon5 from './icon5.gif'
import icon6 from './icon6.gif'
import icon7 from './icon7.gif'
import icon8 from './icon8.gif'
import icon9 from './icon9.gif'


export {
  icon0,
  icon1,
  icon2,
  icon3,
  icon4,
  icon5,
  icon6,
  icon7,
  icon8,
  icon9,
}

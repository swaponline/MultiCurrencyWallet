import React, { Component } from 'react'

import styles from './NewWallet.scss'
import cssModules from 'react-css-modules'

@cssModules(styles)
export default class NewWallet extends Component {
  render() {
    return (
      <div styleName="container">

      </div>
    )
  }
}

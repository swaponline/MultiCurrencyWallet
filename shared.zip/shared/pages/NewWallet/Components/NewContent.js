import React, { Component } from 'react'

import styles from './NewContent.scss'
import cssModules from 'react-css-modules'

import PromoText from './PromoText/PromoText'
import CurrencySlider from './CurrencySlider/CurrencySlider'


@cssModules(styles)
export default class NewContent extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}

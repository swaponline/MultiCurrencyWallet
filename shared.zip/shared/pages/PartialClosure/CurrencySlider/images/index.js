
import btc from './btc.svg'
import dash from './dash.svg'
import eth from './eth.svg'
import fire from './fire.svg'
import ltc from './ltc.svg'
import swap from './swap.svg'
import trx from './trx.svg'
import usdt from './usdt.svg'
import xrp from './xrp.svg'


export {
  btc,
  dash,
  eth,
  fire,
  ltc,
  swap,
  trx,
  usdt,
  xrp,
}

const minAmount = {
  eth: 0.001,
  btc: 0.00015,
  ltc: 0.1,
  eos: 1,
  tlos: 1,
  noxon: 1,
  swap: 1,
  jot: 1,
  usdt: 0,
  erc: 1,
}

export default minAmount

const coinsWithDynamicFee = [
  'eth',
  'ltc',
  'btc',
]


export default coinsWithDynamicFee

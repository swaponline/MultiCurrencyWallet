const minAmountOffer = {
  eth: 0.0006,
  btc: 0.0002,
  ltc: 0.1,
  eos: 1,
  jot: 1,
  usdt: 0,
  erc: 1,
}

export default minAmountOffer

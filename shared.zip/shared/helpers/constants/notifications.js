export default {
  SuccessWithdraw: 'SuccessWithdraw',
  Message: 'Message',
  ErrorNotification: 'ErrorNotification',
}

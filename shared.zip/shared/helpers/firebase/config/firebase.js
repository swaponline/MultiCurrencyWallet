export const config = {
  apiKey: 'AIzaSyCLDnjBviZvVS3X2CosmvxJTmtxAtXCB04',
  authDomain: 'swap155-212716.firebaseapp.com',
  databaseURL: 'https://swap155-212716.firebaseio.com',
  projectId: 'swap155-212716',
  storageBucket: 'swap155-212716.appspot.com',
  messagingSenderId: '681929431956',
}

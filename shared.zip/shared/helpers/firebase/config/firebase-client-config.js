const clientConfig = {
  apiKey: 'AIzaSyD-k8E9opfx9kgEa8XK8f19GmrVG5ozl60',
  authDomain: 'ninth-archway-195817.firebaseapp.com',
  databaseURL: 'https://ninth-archway-195817.firebaseio.com',
  projectId: 'ninth-archway-195817',
  storageBucket: '',
  messagingSenderId: '1083972351463',
}
// now it's me
export default clientConfig

const level = require('level-js')


module.exports = window.leveldown || level

import { reducers } from 'redux/core/reducers'


export const setIsDisplayingTable = (payload) => {
  reducers.menu.setIsDisplayingTable(payload)
}

import token from './token'


export default {
  ...token,
}

import reducers from 'redux/core/reducers'


const setSigned = () => {
  reducers.signUp.setSigned()
}

export default {
  setSigned,
}
